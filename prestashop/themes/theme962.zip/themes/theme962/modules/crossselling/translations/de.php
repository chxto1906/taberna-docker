<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{crossselling}prestashop>crossselling_46532f43e161343763ff815e5208f7e9'] = 'Block Cross-Selling';
$_MODULE['<{crossselling}prestashop>crossselling_83bcd48a4b3938f7cd10c898ece01adf'] = 'Zeigt auf jeder Artikelseite eine Sektion "Kunden, die dieses Artikel gekauft haben, kauften auch ..." an.';
$_MODULE['<{crossselling}prestashop>crossselling_462390017ab0938911d2d4e964c0cab7'] = 'Einstellungen wurden aktualisiert';
$_MODULE['<{crossselling}prestashop>crossselling_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{crossselling}prestashop>crossselling_b6bf131edd323320bac67303a3f4de8a'] = 'Artikelpreise anzeigen';
$_MODULE['<{crossselling}prestashop>crossselling_70f9a895dc3273d34a7f6d14642708ec'] = 'Artikelpreise im Block mitanzeigen.';
$_MODULE['<{crossselling}prestashop>crossselling_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{crossselling}prestashop>crossselling_19a799a6afd0aaf89bc7a4f7588bbf2c'] = 'Anzahl der Artikel, die angezeigt werden';
$_MODULE['<{crossselling}prestashop>crossselling_02128de6a3b085c72662973cd3448df2'] = 'Legen Sie die Anzahl der Artikel fest, die in diesem Block angezeigt werden.';
$_MODULE['<{crossselling}prestashop>crossselling_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{crossselling}prestashop>crossselling_10ac3d04253ef7e1ddc73e6091c0cd55'] = 'Weiter';
$_MODULE['<{crossselling}prestashop>crossselling_0f169d3dc0db47a4074489a89cb034b5'] = 'Wir empfehlen';


return $_MODULE;
