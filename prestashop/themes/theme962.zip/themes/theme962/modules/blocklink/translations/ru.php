<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklink}prestashop>blocklink_fc738410141e4ec0c0319a81255a1431'] = 'Блок ссылок';
$_MODULE['<{blocklink}prestashop>blocklink_baa2ae9622a47c3217d725d1537e5187'] = 'Добавляет блок с дополнительными ссылками.';
$_MODULE['<{blocklink}prestashop>blocklink_9394bb34611399534ffac4f0ece96b7f'] = 'Неверный URL';
$_MODULE['<{blocklink}prestashop>blocklink_3da9d5745155a430aac6d7de3b6de0c8'] = 'Ссылка была добавлена.';
$_MODULE['<{blocklink}prestashop>blocklink_898536ebd630aa3a9844e9cd9d1ebb9b'] = 'Ошибка при создании ссылки.';
$_MODULE['<{blocklink}prestashop>blocklink_b18032737875f7947443c98824103a1f'] = 'Поле "Название" не может быть пустым.';
$_MODULE['<{blocklink}prestashop>blocklink_43b38b9a2fe65059bed320bd284047e3'] = 'Поле \\"заглавие\\" неверное';
$_MODULE['<{blocklink}prestashop>blocklink_eb74914f2759760be5c0a48f699f8541'] = 'Ошибка при обновлении названия.';
$_MODULE['<{blocklink}prestashop>blocklink_5c0f7e2db8843204f422a369f2030b37'] = 'Блок заголовка был обновлен.';
$_MODULE['<{blocklink}prestashop>blocklink_5d73d4c0bcb035a1405e066eb0cdf832'] = 'Произошла ошибка во время удаления ссылки.';
$_MODULE['<{blocklink}prestashop>blocklink_9bbcafcc85be214aaff76dffb8b72ce9'] = 'Ссылка была удалена.';
$_MODULE['<{blocklink}prestashop>blocklink_7e5748d8c44f33c9cde08ac2805e5621'] = 'Обновление порядок сортировки';
$_MODULE['<{blocklink}prestashop>blocklink_46cff2568b00bc09d66844849d0b1309'] = 'Произошла ошибка во время настройки сортировки .';
$_MODULE['<{blocklink}prestashop>blocklink_58e9b25bb2e2699986a3abe2c92fc82e'] = 'Добавить ссылку';
$_MODULE['<{blocklink}prestashop>blocklink_ed2fc2838f7edb7607dd1cd19f3a82e0'] = 'Текст:';
$_MODULE['<{blocklink}prestashop>blocklink_1f3674ab0d54a38327e8e4a0d97788d4'] = 'Открыть в новом окне:';
$_MODULE['<{blocklink}prestashop>blocklink_f16b5952df8d25ea30b25ff95ee8fedf'] = 'Ассоциация магазина';
$_MODULE['<{blocklink}prestashop>blocklink_7f3ee1818e42cfd668e361d89b8595fb'] = 'Добавить эту ссылку';
$_MODULE['<{blocklink}prestashop>blocklink_b22c8f9ad7db023c548c3b8e846cb169'] = 'Название блока';
$_MODULE['<{blocklink}prestashop>blocklink_2c906769e7f8b03cc1fedce4e24a20c2'] = 'Заглавие блока:';
$_MODULE['<{blocklink}prestashop>blocklink_67c94c1cba852f2d13eed115c938baf6'] = 'URL блока:';
$_MODULE['<{blocklink}prestashop>blocklink_06933067aafd48425d67bcb01bba5cb6'] = 'Изменить';
$_MODULE['<{blocklink}prestashop>blocklink_490aa6e856ccf208a054389e47ce0d06'] = 'ID';
$_MODULE['<{blocklink}prestashop>blocklink_387a8014f530f080bf2f3be723f8c164'] = 'Список ссылок';
$_MODULE['<{blocklink}prestashop>blocklink_9d55fc80bbb875322aa67fd22fc98469'] = 'Ассоциация магазина';
$_MODULE['<{blocklink}prestashop>blocklink_d36e9f57ea37903f81d28f7a189b9649'] = 'по самым новым ссылкам';
$_MODULE['<{blocklink}prestashop>blocklink_6ccdff04699ffe6956a6b1465907414a'] = 'по самым старым ссылкам';


return $_MODULE;
