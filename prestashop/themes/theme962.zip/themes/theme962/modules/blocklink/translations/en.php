<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklink}prestashop>blocklink_fc738410141e4ec0c0319a81255a1431'] = 'Link block';
$_MODULE['<{blocklink}prestashop>blocklink_baa2ae9622a47c3217d725d1537e5187'] = 'Adds a block with additional links.';
$_MODULE['<{blocklink}prestashop>blocklink_8d85948ef8fda09c2100de886e8663e5'] = 'Are you sure you want to delete all your links?';
$_MODULE['<{blocklink}prestashop>blocklink_b15e7271053fe9dd22d80db100179085'] = 'This module need to be hooked in a column and your theme does not implement one';
$_MODULE['<{blocklink}prestashop>blocklink_666f6333e43c215212b916fef3d94af0'] = 'You must fill in all fields.';
$_MODULE['<{blocklink}prestashop>blocklink_9394bb34611399534ffac4f0ece96b7f'] = 'Bad URL';
$_MODULE['<{blocklink}prestashop>blocklink_3da9d5745155a430aac6d7de3b6de0c8'] = 'The link has been added.';
$_MODULE['<{blocklink}prestashop>blocklink_898536ebd630aa3a9844e9cd9d1ebb9b'] = 'An error occurred during link creation.';
$_MODULE['<{blocklink}prestashop>blocklink_b18032737875f7947443c98824103a1f'] = '"title" field cannot be empty.';
$_MODULE['<{blocklink}prestashop>blocklink_43b38b9a2fe65059bed320bd284047e3'] = 'The \'title\' field is invalid';
$_MODULE['<{blocklink}prestashop>blocklink_eb74914f2759760be5c0a48f699f8541'] = 'An error occurred during title updating.';
$_MODULE['<{blocklink}prestashop>blocklink_5c0f7e2db8843204f422a369f2030b37'] = 'The block title has been updated.';
$_MODULE['<{blocklink}prestashop>blocklink_5d73d4c0bcb035a1405e066eb0cdf832'] = 'An error occurred during link deletion.';
$_MODULE['<{blocklink}prestashop>blocklink_9bbcafcc85be214aaff76dffb8b72ce9'] = 'The link has been deleted.';
$_MODULE['<{blocklink}prestashop>blocklink_7e5748d8c44f33c9cde08ac2805e5621'] = 'Sort order updated';
$_MODULE['<{blocklink}prestashop>blocklink_46cff2568b00bc09d66844849d0b1309'] = 'An error occurred during sort order set-up.';
$_MODULE['<{blocklink}prestashop>blocklink_58e9b25bb2e2699986a3abe2c92fc82e'] = 'Add a new link';
$_MODULE['<{blocklink}prestashop>blocklink_ed2fc2838f7edb7607dd1cd19f3a82e0'] = 'Text:';
$_MODULE['<{blocklink}prestashop>blocklink_3b3d06023f6353f8fd05f859b298573e'] = 'URL:';
$_MODULE['<{blocklink}prestashop>blocklink_1f3674ab0d54a38327e8e4a0d97788d4'] = 'Open in a new window:';
$_MODULE['<{blocklink}prestashop>blocklink_f16b5952df8d25ea30b25ff95ee8fedf'] = 'Shop association:';
$_MODULE['<{blocklink}prestashop>blocklink_7f3ee1818e42cfd668e361d89b8595fb'] = 'Add this link';
$_MODULE['<{blocklink}prestashop>blocklink_b22c8f9ad7db023c548c3b8e846cb169'] = 'Block title';
$_MODULE['<{blocklink}prestashop>blocklink_2c906769e7f8b03cc1fedce4e24a20c2'] = 'Block title:';
$_MODULE['<{blocklink}prestashop>blocklink_67c94c1cba852f2d13eed115c938baf6'] = 'Block URL:';
$_MODULE['<{blocklink}prestashop>blocklink_06933067aafd48425d67bcb01bba5cb6'] = 'Update';
$_MODULE['<{blocklink}prestashop>blocklink_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{blocklink}prestashop>blocklink_9b9d1ed2e377a28925de723d1d300e91'] = 'Order list by:';
$_MODULE['<{blocklink}prestashop>blocklink_704b746de8f87e82d5193ceb523d872a'] = 'most recent links';
$_MODULE['<{blocklink}prestashop>blocklink_027434466fc0739d79a00730024657a1'] = 'oldest links';
$_MODULE['<{blocklink}prestashop>blocklink_490aa6e856ccf208a054389e47ce0d06'] = 'Id';
$_MODULE['<{blocklink}prestashop>blocklink_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Text';
$_MODULE['<{blocklink}prestashop>blocklink_02a3a357710cc2a5dfdfb74ed012fb59'] = 'Url';
$_MODULE['<{blocklink}prestashop>blocklink_387a8014f530f080bf2f3be723f8c164'] = 'Link list';
$_MODULE['<{blocklink}prestashop>blocklink_e124f0a8a383171357b9614a45349fb5'] = 'Open in a new window';
$_MODULE['<{blocklink}prestashop>blocklink_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{blocklink}prestashop>blocklink_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{blocklink}prestashop>blocklink_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{blocklink}prestashop>blocklink_9d55fc80bbb875322aa67fd22fc98469'] = 'Shop association';
$_MODULE['<{blocklink}prestashop>blocklink_861dc984a1e9aa1e7fef283b4886c2b6'] = 'Add a new block';
$_MODULE['<{blocklink}prestashop>blocklink_b78a3223503896721cca1303f776159b'] = 'Title';
$_MODULE['<{blocklink}prestashop>blocklink_aed3f8ab8adeac5f8a45a3a675cff941'] = 'Order list';
$_MODULE['<{blocklink}prestashop>blocklink_d36e9f57ea37903f81d28f7a189b9649'] = 'by most recent links';
$_MODULE['<{blocklink}prestashop>blocklink_6ccdff04699ffe6956a6b1465907414a'] = 'by oldest links';


return $_MODULE;
