<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockviewed}prestashop>blockviewed_859e85774d372c6084d62d02324a1cc3'] = 'Блок просмотренных товаров';
$_MODULE['<{blockviewed}prestashop>blockviewed_eaa362292272519b786c2046ab4b68d2'] = 'Добавляет блок последних просмотренных товаров.';
$_MODULE['<{blockviewed}prestashop>blockviewed_2e57399079951d84b435700493b8a8c1'] = 'Вы должны заполнить поле \'Отображаемые товары\'';
$_MODULE['<{blockviewed}prestashop>blockviewed_d36bbb6066e3744039d38e580f17a2cc'] = 'Укажите количество товаров, отображаемых в блоке';
$_MODULE['<{blockviewed}prestashop>blockviewed_43560641f91e63dc83682bc598892fa1'] = 'Просмотренные товары';
$_MODULE['<{blockviewed}prestashop>blockviewed_8f7f4c1ce7a4f933663d10543562b096'] = 'Подробнее';


return $_MODULE;
