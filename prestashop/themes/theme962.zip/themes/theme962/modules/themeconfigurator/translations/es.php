<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_e92dabb4907f1957cabc469cca4deefc'] = 'Configurador de temas';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_cf8fdaf6e745133c90516eb9b74e31c3'] = 'Configura los elementos principales de tu tema.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_eedb7e9e8a884cb0a78a55528e8b8fab'] = '¡Más de 500 plantillas para usuarios premium! ¡Míralas ya!';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_149cd107b688af7a007e739fd51ac919'] = 'Eliminado con éxito.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_ec870aa68b135c4f3adc9a3a2731ddbc'] = 'No se puede eliminar eso.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_3ee0c881516fce384747e3107dbfc538'] = 'Contenido no válido';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_dd2681ec1593dd537587be3389ee24d3'] = 'Se ha producido un error al guardar los datos.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_b9099a0a16c40efc8b73f548144d472f'] = 'Actualizado correctamente.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Se ha producido un error mientras se subía la imagen.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_dccadfc1bf4714d72add6b2332505009'] = 'Nuevo elemento añadido correctamente.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_f1206f9fadc5ce41694f69129aecac26'] = 'Configurar';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_6e3670bb5e3826106c5243b242cc52d9'] = 'Mostrar enlaces a las redes sociales de tu tienda (Twitter, Facebook, etc.)';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_4bae4cdd2d56a5a8b8c320288c5d3426'] = 'Mostrar información de contacto';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_17a84b9793933f127b961f44b9c8bcbc'] = 'Mostrar botones para compartir productos en redes sociales';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_6080ab31226b39af728c2d40fd57f0d0'] = 'Mostrar el bloque de Facebook en la página principal';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_87965e506665f83903c1de5d3ad0c98e'] = 'Activar vista rápida';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_158fc4b90f7acab3770c57827fb0e424'] = 'Activar logotipo superior';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_cf5ca43ed94712fe0160fff0a523b8ef'] = 'Mostrar logotipos de pago de tu producto';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_2e1328793a14abff890f7bae4234328c'] = 'Activar configurador en vivo';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_f5a35b8e88be7f51ad3a3714a83df3a1'] = 'La herramienta de personalización te permite cambiar el color y la fuente de tu tema.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_b952538cab3142a26ac46f8da619e2f9'] = 'Solo tu puedes ver esto: %s (tus visitantes no lo verán).';
$_MODULE['<{themeconfigurator}prestashop>items_b9b371458ab7c314f88b81c553f6ce51'] = 'Gancho';
$_MODULE['<{themeconfigurator}prestashop>items_7dce122004969d56ae2e0245cb754d35'] = 'Modificar';
$_MODULE['<{themeconfigurator}prestashop>items_d3d2e617335f08df83599665eef8a418'] = 'Cerrar';
$_MODULE['<{themeconfigurator}prestashop>items_e8cf85cec621489ec026f7e06c67eb4e'] = 'Eliminar elemento';
$_MODULE['<{themeconfigurator}prestashop>items_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activo';
$_MODULE['<{themeconfigurator}prestashop>items_be53a0541a6d36f6ecb879fa2c584b08'] = 'Imagen';
$_MODULE['<{themeconfigurator}prestashop>items_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Ancho de imagen';
$_MODULE['<{themeconfigurator}prestashop>items_21de26caa6bcfc936378c4e45d235bd9'] = 'px';
$_MODULE['<{themeconfigurator}prestashop>items_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Alto de imagen';
$_MODULE['<{themeconfigurator}prestashop>items_4c87eb073eb09f42281d7e67aeacb223'] = 'Objetivo';
$_MODULE['<{themeconfigurator}prestashop>items_4c4ad5fca2e7a3f74dbb1ced00381aa4'] = 'HTML';
$_MODULE['<{themeconfigurator}prestashop>items_ea4788705e6873b424c65e91c2846b19'] = 'Cancelar';
$_MODULE['<{themeconfigurator}prestashop>items_f453e0c33edd79653febd0b9bc8f09b3'] = 'No hay elementos disponibles';
$_MODULE['<{themeconfigurator}prestashop>new_ff19c966036b4a0c7350b2fc7e2861c2'] = 'Añadir elemento';
$_MODULE['<{themeconfigurator}prestashop>new_4994a8ffeba4ac3140beb89e8d41f174'] = 'Idioma';
$_MODULE['<{themeconfigurator}prestashop>new_2c92d496fa8efe3d5b2b38c185f9b7f7'] = 'Usar título frontal';
$_MODULE['<{themeconfigurator}prestashop>new_be53a0541a6d36f6ecb879fa2c584b08'] = 'Imagen';
$_MODULE['<{themeconfigurator}prestashop>new_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Ancho de imagen';
$_MODULE['<{themeconfigurator}prestashop>new_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Alto de imagen';
$_MODULE['<{themeconfigurator}prestashop>new_ea4788705e6873b424c65e91c2846b19'] = 'Cancelar';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_07a20508306b4d6c2532e80dd38e2c7f'] = 'Solo tu puedes ver esta herramienta (porque estás identificado como mercante de la empresa); tus visitantes no podrán.';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_402bf0c47e80d12feba49f31fdcbc11f'] = 'Color del tema';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_194f5394ae2e9c74dc3c441b92862d1d'] = 'Fuente';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_9a2c00f5f6df185a8d7d421ee70ccddf'] = 'Fuente del título';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_ea3aba27f515989b46d990e95a097818'] = 'Elige una fuente';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_526d688f37a86d3c3f27d0c5016eb71d'] = 'Borrar filtro';


return $_MODULE;
