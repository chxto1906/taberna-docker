<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_149cd107b688af7a007e739fd51ac919'] = 'Удаление завершено';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Во время загрузки картинки произошла ошибка.';
$_MODULE['<{themeconfigurator}prestashop>themeconfigurator_f1206f9fadc5ce41694f69129aecac26'] = 'Настроить';
$_MODULE['<{themeconfigurator}prestashop>items_7dce122004969d56ae2e0245cb754d35'] = 'Редактировать';
$_MODULE['<{themeconfigurator}prestashop>items_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Активен';
$_MODULE['<{themeconfigurator}prestashop>items_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Ширина изображения';
$_MODULE['<{themeconfigurator}prestashop>items_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Высота изображения';
$_MODULE['<{themeconfigurator}prestashop>new_4994a8ffeba4ac3140beb89e8d41f174'] = 'Язык';
$_MODULE['<{themeconfigurator}prestashop>new_6fed80a8c8ded2f5e14a687e4a443abc'] = 'Ширина изображения';
$_MODULE['<{themeconfigurator}prestashop>new_2aa3aa9d021c7cfffb5afa08f52fbc51'] = 'Высота изображения';
$_MODULE['<{themeconfigurator}prestashop>live_configurator_526d688f37a86d3c3f27d0c5016eb71d'] = 'Сброс';


return $_MODULE;
