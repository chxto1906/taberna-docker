<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksupplier}prestashop>blocksupplier_9ae42413e3cb9596efe3857f75bad3df'] = 'Bloque proveedor';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_e72b2501ba75e9ab754d3294d43c2590'] = 'Añadir un bloque que muestre sus proveedores.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_85ab0c0d250e58397e95c96277a3f8e3'] = 'Número de elementos incorrecto.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_914b0cd4e4aa7cba84a3fd47b880fd2a'] = 'Por favor, active al menos un tipo de lista.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_78b2098aa1d513b5e1852b3140c7ee26'] = 'Mostrar proveedores en lista de texto plano.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_e490c3b296d2f54d65d3d20803f71b55'] = 'Mostrar los proveedores en un menu desplegable.';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Proveedores';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'Más sobre';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_ecf253735ac0cba84a9d2eeff1f1b87c'] = 'Todos los proveedores';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_496689fbd342f80d30f1f266d060415a'] = 'No hay proveedores';


return $_MODULE;
