<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{homeslider}prestashop>homeslider_693b83f5eca43e2bb1675287c37ce9e2'] = 'Imagen de control deslizante para su página web';
$_MODULE['<{homeslider}prestashop>homeslider_c17aed434289cedd02618451e12c8da6'] = 'Agrega un control deslizante de la imagen a tu página principal.';
$_MODULE['<{homeslider}prestashop>homeslider_3f80dc2cdd06939d4f5514362067cd86'] = 'Valores no válidos';
$_MODULE['<{homeslider}prestashop>homeslider_a6abafe564d3940cc36ee43e2f09400b'] = 'Diapositiva no válido';
$_MODULE['<{homeslider}prestashop>homeslider_e0ce30bfbf90d2306ecf72f06a83133f'] = 'Estado no válido de diapositivas.';
$_MODULE['<{homeslider}prestashop>homeslider_9f79795e050649dc6b8bd0cdc874cbdc'] = 'Posición de la diapositiva no  válido.';
$_MODULE['<{homeslider}prestashop>homeslider_76ad3ac84a702b0497cd6be8e8886d34'] = 'id_slide no válido';
$_MODULE['<{homeslider}prestashop>homeslider_14f09fd0804a8f1cd0eb757125fc9c28'] = 'El título es demasiado largo';
$_MODULE['<{homeslider}prestashop>homeslider_39fc40a0ebcbfcae901d20ab8980f188'] = 'La leyenda es demasiado largo';
$_MODULE['<{homeslider}prestashop>homeslider_4477f672766f6f255f760649af8bd92a'] = 'La URL es demasiado larga';
$_MODULE['<{homeslider}prestashop>homeslider_62239300ba982b06ab0f1aa7100ad297'] = 'Descripción es demasiado larga';
$_MODULE['<{homeslider}prestashop>homeslider_980f56796b8bf9d607283de9815fe217'] = 'Formato de URL no es correcta';
$_MODULE['<{homeslider}prestashop>homeslider_73133ce32267e8c7a854d15258eb17e0'] = 'Nombre de archivo no válido.';
$_MODULE['<{homeslider}prestashop>homeslider_349097dadf7e6b01dd2af601d54fd59a'] = 'El título no se encuentra';
$_MODULE['<{homeslider}prestashop>homeslider_ab53605e4a73424d186afccef7b4bc03'] = 'La leyenda no se ha establecido';
$_MODULE['<{homeslider}prestashop>homeslider_0f059227d0a750ce652337d911879671'] = 'URL no se encuentra';
$_MODULE['<{homeslider}prestashop>homeslider_8cf45ba354f4725ec8a0d31164910895'] = 'La imagen no se especifico';
$_MODULE['<{homeslider}prestashop>homeslider_7f82c65d548588c8d5412463c182e450'] = 'La configuración no ha podido actualizar';
$_MODULE['<{homeslider}prestashop>homeslider_7cc92687130ea12abb80556681538001'] = 'Se produjo un error durante la carga de imágenes.';
$_MODULE['<{homeslider}prestashop>homeslider_cdf841e01e10cae6355f72e6838808eb'] = 'El slide no se puede añadir';
$_MODULE['<{homeslider}prestashop>homeslider_eb28485b92fbf9201918698245ec6430'] = 'El slide no se puede actualizar';
$_MODULE['<{homeslider}prestashop>homeslider_55b75a0d59fc613fa2e572226266ff08'] = 'Deslizar información';
$_MODULE['<{homeslider}prestashop>homeslider_792744786ed30c5623dd1cf0c16f4ffe'] = 'Seleccione un archivo';
$_MODULE['<{homeslider}prestashop>homeslider_9b27e12d584b3438e811533b32e026e8'] = 'Inscripción';
$_MODULE['<{homeslider}prestashop>homeslider_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Descripción';
$_MODULE['<{homeslider}prestashop>homeslider_4d3d769b812b6faa6b76e1a8abaece2d'] = 'Activo';
$_MODULE['<{homeslider}prestashop>homeslider_93cba07454f06a4a960172bbd6e2a435'] = 'Sí';
$_MODULE['<{homeslider}prestashop>homeslider_477964da3b7a710156efc82fc4bc72e2'] = 'Ancho máximo';
$_MODULE['<{homeslider}prestashop>homeslider_44877c6aa8e93fa5a91c9361211464fb'] = 'Velocidad';
$_MODULE['<{homeslider}prestashop>homeslider_105b296a83f9c105355403f3332af50f'] = 'Pausa';
$_MODULE['<{homeslider}prestashop>homeslider_1e6a508c037fc42ef6155eeadbb80331'] = 'Reproducir automáticamente';
$_MODULE['<{homeslider}prestashop>list_c82324ebbcea34f55627a897b37190e3'] = 'Lista de diapositivas';
$_MODULE['<{homeslider}prestashop>list_7dce122004969d56ae2e0245cb754d35'] = 'Modificar';


return $_MODULE;
