<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_e0de5a06213f21c55ca3283c009e0907'] = 'Bloc confidentialité des données clients';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f192f208f0bc97af4c5213eee3e78793'] = 'Ajoute un bloc qui affiche un message concernant la confidentialité des données clients.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'Les informations personnelles que nous collectons sont destinées à mieux répondre à vos demandes et traiter vos commandes.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_d847e75da5489bbc525b6f6548d7f50a'] = 'Vous disposez à tout moment d’un droit d’accès, de modification et de suppression de vos informations personnelles que vous pouvez exercer via la page "Mon Compte" de ce site internet.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'Configuration mise à jour';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Veuillez accepter nos conditions concernant la confidentialité des données clients, en cochant la case ci-dessous.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_f4f70727dc34561dfde1a3c529b6205c'] = 'Réglages';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_aafe06caae02aee29775402368a6d22c'] = 'Message concernant la confidentialité des données clients';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Le message sera affiché sur le formulaire de création de compte.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_4df598f7b52577f4bc8d7d408c91eb1a'] = 'Conseil : Si le message est trop long pour être affiché directement dans le formulaire, vous pouvez ajouter un lien vers l\'une de vos pages CMS et écrire le message sur cette page. Vous pouvez créer facilement des pages CMS via le menu "CMS" sous "Préférences".';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Confidentialité des données clients';


return $_MODULE;
