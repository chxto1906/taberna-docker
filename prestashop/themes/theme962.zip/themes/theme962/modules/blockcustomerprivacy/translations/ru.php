<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_d71315851e7e67cbacf5101c5c4ab83d'] = 'Личные данные, которые вы предоставляете, используются для обработки ваших заказов и сообщений, а так же для обеспечения доступа к интересующей вас информации.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb32badede7c8613fddb8502d847c18b'] = 'Пожалуйста, согласитесь с правилами обработки конфиденциальных данных о клиентах, поставив флажок ниже.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_03e1a999dcdb904300ee1b1e767c83c9'] = 'Сообщение, которое отображено в форме создания счета.';
$_MODULE['<{blockcustomerprivacy}prestashop>blockcustomerprivacy_fb0440f9ca32a8b49eded51b09e70821'] = 'Конфиденциальность данных о клиентах';


return $_MODULE;
