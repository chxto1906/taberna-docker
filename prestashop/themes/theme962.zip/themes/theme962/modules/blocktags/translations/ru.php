<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocktags}prestashop>blocktags_f2568a62d4ac8d1d5b532556379772ba'] = 'Блок тегов';
$_MODULE['<{blocktags}prestashop>blocktags_189f63f277cd73395561651753563065'] = 'Тэги';
$_MODULE['<{blocktags}prestashop>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Подробнее о';
$_MODULE['<{blocktags}prestashop>blocktags_4e6307cfde762f042d0de430e82ba854'] = 'Метки пока не установлены';
$_MODULE['<{blocktags}prestashop>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'Тэги еще не созданы';


return $_MODULE;
