<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_b97d23f7cde011d190f39468e146425e'] = 'Блок Моя учетная запись в подвале';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_abdb95361b4c92488add0a5a37afabcb'] = 'Отображает блок со ссылками связанными с учетной записью пользователя.';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_ae9ec80afffec5a455fbf2361a06168a'] = 'Управление моей учетной записью покупателя';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_5973e925605a501b18e48280f04f0347'] = 'Список моих возвратов товара';
$_MODULE['<{blockmyaccountfooter}prestashop>blockmyaccountfooter_b4b80a59559e84e8497f746aac634674'] = 'Управление моими персональными данными';


return $_MODULE;
