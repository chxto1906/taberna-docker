<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockfacebook}prestashop>blockfacebook_06d770829707bb481258791ca979bd2a'] = 'Bloque Facebook';
$_MODULE['<{blockfacebook}prestashop>blockfacebook_f66e16efd2f1f43944e835aa527f9da8'] = 'Muestra un bloque para suscribirse a su página de Facebook.';
$_MODULE['<{blockfacebook}prestashop>blockfacebook_5a67f55ebe6b8e4056f9c285fa762d70'] = 'Nombre de Facebook';
$_MODULE['<{blockfacebook}prestashop>blockfacebook_a4aa9244ea53b5d916dfd8f024d11e22'] = 'Síguenos en Facebook';


return $_MODULE;
