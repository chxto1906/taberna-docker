<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklanguages}prestashop>blocklanguages_d5988791c07fedc0e2fc77683b4e61f6'] = 'Block Sprachen';
$_MODULE['<{blocklanguages}prestashop>blocklanguages_4240df073b78e89bbc9d20ef454e34c3'] = 'Fügt einen Block zur Auswahl der Shop-Sprache für den Kunden hinzu.';


return $_MODULE;
