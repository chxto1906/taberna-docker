<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocklanguages}prestashop>blocklanguages_d5988791c07fedc0e2fc77683b4e61f6'] = 'Bloc langues';
$_MODULE['<{blocklanguages}prestashop>blocklanguages_4240df073b78e89bbc9d20ef454e34c3'] = 'Ajoute un bloc permettant à vos clients de sélectionner la langue de votre boutique.';


return $_MODULE;
