<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcms}prestashop>blockcms_cdca12007979fc49008fd125cdb775fc'] = 'Добавляет блок с ссылками на страницы.';
$_MODULE['<{blockcms}prestashop>blockcms_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Информация';
$_MODULE['<{blockcms}prestashop>blockcms_ea4788705e6873b424c65e91c2846b19'] = 'Отменить';
$_MODULE['<{blockcms}prestashop>blockcms_ef61fb324d729c341ea8ab9901e23566'] = 'Добавить';
$_MODULE['<{blockcms}prestashop>blockcms_97390dd0b5ba7867120aee2ff22bfa38'] = 'Настройка CMS-блока';
$_MODULE['<{blockcms}prestashop>blockcms_94ff014237f6f5cbf5c3655f5ef513c9'] = 'Блоки CMS';
$_MODULE['<{blockcms}prestashop>blockcms_965be994da393e5aa15bd3a2444c6ccf'] = 'Настройка футера';
$_MODULE['<{blockcms}prestashop>blockcms_89887a6d62110cbd72c15218a2d0fda9'] = 'Отображает различные ссылки и информацию в нижнем колонтитуле (footer)';
$_MODULE['<{blockcms}prestashop>blockcms_e363df19c685465bca24d0c06d9394c7'] = 'Отметьте все страницы , которые должны отображаться в футере CMS блока';
$_MODULE['<{blockcms}prestashop>blockcms_fc3faf66c0ea5f710cc58d24fbe4a5b6'] = 'Показывать  "Разработано PrestaShop"';
$_MODULE['<{blockcms}prestashop>blockcms_be58fccb15fb119b8c3d485e3a8561c4'] = 'Настройка CMS-блока';
$_MODULE['<{blockcms}prestashop>blockcms_0eb46571f3ff926d8b2408cafcfc17e3'] = 'Редактировать CMS блок';
$_MODULE['<{blockcms}prestashop>blockcms_ac59142b8d4c64f836acbc239e1cebf0'] = 'Новый CMS блок';
$_MODULE['<{blockcms}prestashop>blockcms_51b274d417210e74d2cfe9e0713602f2'] = 'Если оставить это поле пустым, имя блока будет использовать название категории';
$_MODULE['<{blockcms}prestashop>blockcms_ce5bf551379459c1c61d2a204061c455'] = 'Расположение';
$_MODULE['<{blockcms}prestashop>blockcms_945d5e233cf7d6240f6b783b36a374ff'] = 'Слева';
$_MODULE['<{blockcms}prestashop>blockcms_92b09c7c48c520c3c55e497875da437c'] = 'Справа';
$_MODULE['<{blockcms}prestashop>blockcms_55737e084beaa370a127f3f031f1932e'] = 'Контент CMS:';
$_MODULE['<{blockcms}prestashop>blockcms_04313a11bf4a501b7cf2273ea7b32862'] = 'Пометьте все страницы, которые должны отображаться в блоке';
$_MODULE['<{blockcms}prestashop>blockcms_0d6d7a7c758cd16507d4aebf18305691'] = 'Недопустимое значение отображения магазина';
$_MODULE['<{blockcms}prestashop>blockcms_4eb9b68883615faa427da721fad14422'] = 'Неверное расположение блока';
$_MODULE['<{blockcms}prestashop>blockcms_795c54de995b69fe05142dad6f99ef92'] = 'Вы должны выбрать хотя бы одну страницу или подкатегорию для создания блока CMS.';
$_MODULE['<{blockcms}prestashop>blockcms_0788bfffae213b06afb540bf06926652'] = 'Неверная страница CMS или категория';
$_MODULE['<{blockcms}prestashop>blockcms_7125483712689cd7a6f85b466a8a7632'] = 'Слишком длинное имя блока';
$_MODULE['<{blockcms}prestashop>blockcms_ede67d50014846cb8bb1b00d5fde77be'] = 'id_cms_block указан неверно';
$_MODULE['<{blockcms}prestashop>blockcms_2d81a9da91ff3f073e6aecbe42c33e69'] = 'Пожалуйста, введите текст нижнего колонтитула для языка по умолчанию';
$_MODULE['<{blockcms}prestashop>blockcms_a419b919d146d5db83f22d375d329a59'] = 'Неверная активации футера';
$_MODULE['<{blockcms}prestashop>blockcms_20d52180b34f849cb2c885a8451dd328'] = 'Новый блок не может быть создан!';
$_MODULE['<{blockcms}prestashop>blockcms_0c579767f53365887ac199a96e26c591'] = 'Информация в нижнем колонтитуле (footer) обновлена';
$_MODULE['<{blockcms}prestashop>blockcms_c28716416d2fd75a37b4496586755853'] = 'Блок добавлен';
$_MODULE['<{blockcms}prestashop>blockcms_a94db349ae0c662fd55c9d402481165b'] = 'Блок изменен';
$_MODULE['<{blockcms}prestashop>blockcms_87a2663d841b78f01c27c0edb4f50b76'] = 'Удаление завершено';
$_MODULE['<{blockcms}prestashop>blockcms_34c869c542dee932ef8cd96d2f91cae6'] = 'Наши магазины';
$_MODULE['<{blockcms}prestashop>blockcms_d1aa22a3126f04664e0fe3f598994014'] = 'Скидки';
$_MODULE['<{blockcms}prestashop>blockcms_9ff0635f5737513b1a6f559ac2bff745'] = 'Новые товары';
$_MODULE['<{blockcms}prestashop>blockcms_01f7ac959c1e6ebbb2e0ee706a7a5255'] = 'Лидеры продаж';
$_MODULE['<{blockcms}prestashop>blockcms_5813ce0ec7196c492c97596718f71969'] = 'Карта сайта';
$_MODULE['<{blockcms}prestashop>form_4dabfa54822012dfc78d6ef40f224173'] = 'Блоки слева';
$_MODULE['<{blockcms}prestashop>form_d9ca3009e18447d91cd2e324e8e680ce'] = 'Блоки справа';
$_MODULE['<{blockcms}prestashop>form_b718adec73e04ce3ec720dd11a06a308'] = '№';
$_MODULE['<{blockcms}prestashop>form_83ef1503b3bd9858cc923a74e5f9e917'] = 'Название блока';
$_MODULE['<{blockcms}prestashop>form_bb34a159a88035cce7ef1607e7907f8f'] = 'Название категории';
$_MODULE['<{blockcms}prestashop>form_52f5e0bc3859bc5f5e25130b6c7e8881'] = 'Позиция';
$_MODULE['<{blockcms}prestashop>form_06df33001c1d7187fdd81ea1f5b277aa'] = 'Действия';
$_MODULE['<{blockcms}prestashop>form_08a38277b0309070706f6652eeae9a53'] = 'Вниз';
$_MODULE['<{blockcms}prestashop>form_258f49887ef8d14ac268c92b02503aaa'] = 'Вверх';
$_MODULE['<{blockcms}prestashop>form_7dce122004969d56ae2e0245cb754d35'] = 'Редактировать';
$_MODULE['<{blockcms}prestashop>form_49ee3087348e8d44e1feda1917443987'] = 'Имя';
$_MODULE['<{blockcms}prestashop>form_f7c68d40f8727c658e821c6e6d56af07'] = 'Страницы не созданы';


return $_MODULE;
